
public class Assignment1 {

    /**
     * TODO
     * Lets say we want to return for a customer bank account along with his name sperated with comma
     * Input valus -> name = dawit , bankAccount = 12333322
     *
     * @return
     */
    public String customerNameAlongWithHisBankAccountNumber(String name, String bankAccount){
        return null;
    }

    /**
     * TODO
     * In this function we will calculate the distance b/n two points
     * the distance is give in this form
     * Its the square root of (x2 - x1)^2  + (y2-y1)^2
     **/

    public Integer distance(Integer x2, Integer x1, Integer y1, Integer y2){

        return null;
    }

    /**
     * TODO
     *This function will be  used to validate email address of users trying to login to our website
     * Input will be email address
     * out put is boolean true or false
     * @param args
     */

    public Boolean validateEmailAddress(String email){

        return null;
    }
    public static void main(String[] args) {

    }
}
